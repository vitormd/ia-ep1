M = configSimulador(11,7,1,1);
save problema1.mat M

M = configSimulador(31,21,1,1);
save problema2.mat M

M = configSimulador(51,35,1,1);
save problema3.mat M
